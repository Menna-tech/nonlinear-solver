"""
=====================================================================
  حلّال المعادلات غير الخطية - Nonlinear Equation Solver
  الطرق: Newton-Raphson / Modified Newton-Raphson / Secant
  التشغيل:  streamlit run app.py
=====================================================================
"""

from dataclasses import dataclass

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import sympy as sp
from sympy.parsing.sympy_parser import (
    convert_xor,
    implicit_multiplication_application,
    parse_expr,
    standard_transformations,
)

# ---------------------------------------------------------------------
# 1) إعدادات الصفحة والتصميم (CSS)
# ---------------------------------------------------------------------
st.set_page_config(
    page_title="حلّال المعادلات غير الخطية",
    page_icon="📐",
    layout="wide",
)

st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');

    html, body, [class*="css"], .stMarkdown, label, button {
        font-family: 'Cairo', sans-serif !important;
    }
    /* اتجاه النصوص العربية من اليمين لليسار */
    .stMarkdown, .stAlert, label, h1, h2, h3 { direction: rtl; text-align: right; }
    /* حقول إدخال المعادلات تبقى من اليسار لليمين لأنها رموز رياضية */
    input[type="text"], input[type="number"] { direction: ltr; text-align: left; }

    .hero {
        background: linear-gradient(135deg, #4f46e5 0%, #06b6d4 100%);
        color: white; padding: 1.6rem 2rem; border-radius: 18px;
        margin-bottom: 1.2rem; direction: rtl;
        box-shadow: 0 10px 30px rgba(79,70,229,.25);
    }
    .hero h1 { margin: 0; font-size: 2rem; color: white; }
    .hero p  { margin: .3rem 0 0; opacity: .92; }

    div[data-testid="stMetric"] {
        background: rgba(127,127,127,.08); border: 1px solid rgba(127,127,127,.2);
        padding: .9rem 1.1rem; border-radius: 14px; direction: rtl;
    }
    .stButton > button { border-radius: 12px; font-weight: 700; padding: .6rem 1rem; }
    </style>
    <div class="hero">
        <h1>📐 حلّال المعادلات غير الخطية</h1>
        <p>الطرق العددية الهندسية: نيوتن-رافسون • نيوتن المعدّلة • القاطع (Secant)</p>
    </div>
    """,
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------------
# 2) تحليل المعادلات النصية وتحويلها إلى دوال رقمية
# ---------------------------------------------------------------------
X = sp.Symbol("x", real=True)

# الدوال والثوابت المسموح بها داخل النص
ALLOWED = {
    "x": X,
    "e": sp.E,          # العدد النيبري e
    "pi": sp.pi,
    "exp": sp.exp,
    "ln": sp.log,       # اللوغاريتم الطبيعي
    "log": sp.log,      # log = اللوغاريتم الطبيعي
    "log10": lambda v: sp.log(v, 10),
    "sqrt": sp.sqrt,
    "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
    "asin": sp.asin, "acos": sp.acos, "atan": sp.atan,
    "sinh": sp.sinh, "cosh": sp.cosh, "tanh": sp.tanh,
    "abs": sp.Abs,
}

TRANSFORMS = standard_transformations + (
    implicit_multiplication_application,  # يسمح بكتابة 2x بدل 2*x
    convert_xor,                          # يسمح باستخدام ^ بدل **
)


def parse_function(text: str) -> sp.Expr:
    """تحويل نص إلى تعبير SymPy مع التحقق من أن المتغير الوحيد هو x."""
    expr = parse_expr(text.strip(), local_dict=ALLOWED, transformations=TRANSFORMS)
    extra = expr.free_symbols - {X}
    if extra:
        raise ValueError(f"رموز غير معروفة: {', '.join(map(str, extra))} (المتغير المسموح x فقط)")
    return expr


def to_numeric(expr: sp.Expr):
    """تحويل تعبير SymPy إلى دالة NumPy سريعة."""
    return sp.lambdify(X, expr, modules=["numpy"])


def safe_eval(fn, value: float) -> float:
    """تقييم آمن للدالة (يعيد nan عند حدوث خطأ رياضي)."""
    try:
        with np.errstate(all="ignore"):
            return float(np.real(fn(value)))
    except Exception:
        return float("nan")


# ---------------------------------------------------------------------
# 3) الخوارزميات العددية
# ---------------------------------------------------------------------
@dataclass
class SolveResult:
    table: pd.DataFrame
    root: float
    converged: bool
    message: str


COLUMNS = ["i", "x_i", "f(x_i)", "f'(x_i) / الميل", "x_{i+1}", "|x_{i+1} - x_i|"]


def solve_iterative(method, f, df, x0, tol, max_iter, multiplicity=1.0):
    """
    تنفيذ الطريقة المختارة وإرجاع جدول التكرارات.

    Newton-Raphson :  x_{i+1} = x_i - f(x_i)/f'(x_i)
    Modified Newton:  x_{i+1} = x_i - m * f(x_i)/f'(x_i)      (m = تضاعف الجذر)
    Secant         :  x_{i+1} = x_i - f(x_i)(x_i - x_{i-1}) / (f(x_i) - f(x_{i-1}))
    """
    rows = []
    x = float(x0)
    x_prev = x - 0.01 * max(1.0, abs(x))  # نقطة ثانية لطريقة القاطع فقط
    converged = False
    message = "لم يتحقق شرط التوقف خلال العدد الأقصى من التكرارات."

    for i in range(max_iter):
        fx = safe_eval(f, x)

        # --- حساب الميل حسب الطريقة ---
        if method == "Secant (القاطع)":
            f_prev = safe_eval(f, x_prev)
            slope = (fx - f_prev) / (x - x_prev) if x != x_prev else 0.0
        else:
            slope = safe_eval(df, x)

        # --- فحوص الأمان ---
        if not np.isfinite(fx) or not np.isfinite(slope):
            message = f"قيمة غير معرّفة (NaN/∞) عند x = {x:.6g}. جرّب نقطة بداية مختلفة."
            break
        if slope == 0:
            message = f"الميل = 0 عند x = {x:.6g} (قسمة على صفر). جرّب نقطة بداية مختلفة."
            break

        # --- الخطوة التكرارية ---
        step = fx / slope
        if method == "Modified Newton-Raphson (نيوتن المعدّلة)":
            step *= multiplicity
        x_new = x - step
        err = abs(x_new - x)

        rows.append([i, x, fx, slope, x_new, err])

        x_prev, x = x, x_new

        if not np.isfinite(x):
            message = "التكرارات تباعدت (diverged). جرّب نقطة بداية أخرى."
            break
        if err < tol:
            converged = True
            message = f"تحقق شرط التوقف بعد {i + 1} تكرار."
            break

    table = pd.DataFrame(rows, columns=COLUMNS)
    return SolveResult(table, x, converged, message)


# ---------------------------------------------------------------------
# 4) الرسم البياني التفاعلي (Plotly)
# ---------------------------------------------------------------------
def build_plot(f, expr_text, result: SolveResult, x0, show_path):
    root = result.root
    table = result.table

    # نطاق الرسم: يغطي نقطة البداية والجذر مع هامش
    span = max(abs(x0 - root), 1.0) * 1.6
    xs = np.linspace(root - span, root + span, 1200)
    with np.errstate(all="ignore"):
        ys = np.array(f(xs), dtype=float) * np.ones_like(xs)
    ys[~np.isfinite(ys)] = np.nan

    # تحديد مدى المحور y لتفادي القيم الضخمة قرب الانقطاعات
    finite = ys[np.isfinite(ys)]
    y_lim = None
    if finite.size:
        lo, hi = np.percentile(finite, [2, 98])
        pad = (hi - lo) * 0.25 or 1.0
        y_lim = [lo - pad, hi + pad]

    fig = go.Figure()

    # منحنى الدالة
    fig.add_trace(go.Scatter(
        x=xs, y=ys, mode="lines", name="y = f(x)",
        line=dict(color="#4f46e5", width=3),
        hovertemplate="x=%{x:.5f}<br>f(x)=%{y:.5f}<extra></extra>",
    ))

    # مسار التكرارات (الزجزاج: نقطة على المحور ← نقطة على المنحنى)
    if show_path and not table.empty:
        px, py = [], []
        for xi, fi in zip(table["x_i"], table["f(x_i)"]):
            px += [xi, xi]
            py += [0, fi]
        px.append(table["x_{i+1}"].iloc[-1])
        py.append(0)
        fig.add_trace(go.Scatter(
            x=px, y=py, mode="lines", name="مسار التكرارات",
            line=dict(color="#f59e0b", width=1.5, dash="dot"),
            hoverinfo="skip",
        ))
        fig.add_trace(go.Scatter(
            x=table["x_i"], y=table["f(x_i)"], mode="markers+text",
            name="x_i", text=[f"x{int(i)}" for i in table["i"]],
            textposition="top center",
            marker=dict(color="#f59e0b", size=9),
        ))

    # نقطة الجذر
    fig.add_trace(go.Scatter(
        x=[root], y=[0], mode="markers+text", name="الجذر (Root)",
        text=[f"Root ≈ {root:.6f}"], textposition="bottom right",
        marker=dict(color="#ef4444", size=15, symbol="diamond",
                    line=dict(color="white", width=2)),
        hovertemplate="الجذر = %{x:.10f}<extra></extra>",
    ))

    # المحوران X و Y
    fig.add_hline(y=0, line=dict(color="gray", width=1.5))
    fig.add_vline(x=0, line=dict(color="gray", width=1.5))

    fig.update_layout(
        title=f"f(x) = {expr_text}",
        xaxis_title="x", yaxis_title="f(x)",
        height=560, hovermode="closest",
        margin=dict(l=20, r=20, t=60, b=20),
        legend=dict(orientation="h", y=-0.15),
        template="plotly_white",
    )
    fig.update_xaxes(showgrid=True, zeroline=False)
    fig.update_yaxes(showgrid=True, zeroline=False, range=y_lim)
    return fig


# ---------------------------------------------------------------------
# 5) أمثلة جاهزة + إدارة حالة الواجهة
# ---------------------------------------------------------------------
PRESETS = {
    "— اختر مثالاً —": None,
    "x³ − 8x + 5 (x0 = 3)": ("x**3 - 8*x + 5", 3.0),
    "e^(−x) − x (x0 = 1)": ("e**-x - x", 1.0),
    "cos(x) − x (x0 = 1)": ("cos(x) - x", 1.0),
    "x² − 2 (x0 = 1)": ("x**2 - 2", 1.0),
    "x·sin(x) − 1 (x0 = 2)": ("x*sin(x) - 1", 2.0),
}

st.session_state.setdefault("f_text", "x**3 - 8*x + 5")
st.session_state.setdefault("x0", 3.0)


def apply_preset():
    """تعبئة الحقول عند اختيار مثال جاهز."""
    choice = PRESETS[st.session_state["preset"]]
    if choice:
        st.session_state["f_text"], st.session_state["x0"] = choice


# ---------------------------------------------------------------------
# 6) الشريط الجانبي: مدخلات المستخدم
# ---------------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ المدخلات")

    st.selectbox("أمثلة جاهزة", list(PRESETS), key="preset", on_change=apply_preset)

    method = st.selectbox(
        "طريقة الحل",
        ["Newton-Raphson (نيوتن-رافسون)",
         "Modified Newton-Raphson (نيوتن المعدّلة)",
         "Secant (القاطع)"],
    )

    f_text = st.text_input("الدالة f(x)", key="f_text",
                           help="أمثلة: x**3 - 8*x + 5  أو  e**-x - x  أو  cos(x) - x")

    auto_deriv = st.checkbox("حساب المشتقة f'(x) تلقائياً", value=True)
    df_text = ""
    if not auto_deriv and method != "Secant (القاطع)":
        df_text = st.text_input("المشتقة f'(x)", value="3*x**2 - 8")

    x0 = st.number_input("نقطة البداية x₀", key="x0", format="%.6f")

    c1, c2 = st.columns(2)
    tol = c1.number_input("الدقة (Tolerance)", value=1e-8, format="%.1e", min_value=1e-15)
    max_iter = c2.number_input("أقصى تكرارات", value=50, min_value=1, max_value=1000, step=1)

    multiplicity = 1.0
    if method.startswith("Modified"):
        multiplicity = st.number_input("تضاعف الجذر m", value=2.0, min_value=1.0, step=1.0)

    show_path = st.checkbox("إظهار مسار التكرارات على الرسم", value=True)
    run = st.button("🚀 احسب الجذر", type="primary", use_container_width=True)

    st.caption("الدوال المدعومة: sin, cos, tan, exp, ln/log, log10, sqrt, abs, sinh, cosh, tanh… "
               "الثوابت: e, pi. يمكن استخدام ^ أو ** للأس.")

# ---------------------------------------------------------------------
# 7) التنفيذ وعرض النتائج
# ---------------------------------------------------------------------
if not run:
    st.info("👈 أدخل المعادلة ونقطة البداية من الشريط الجانبي ثم اضغط **احسب الجذر**.")
    st.stop()

try:
    f_expr = parse_function(f_text)
    df_expr = parse_function(df_text) if df_text else sp.diff(f_expr, X)
except Exception as exc:  # أخطاء كتابة المعادلة
    st.error(f"❌ تعذّر قراءة المعادلة: {exc}")
    st.stop()

f_num = to_numeric(f_expr)
df_num = to_numeric(df_expr)

result = solve_iterative(method, f_num, df_num, x0, tol, int(max_iter), multiplicity)

# --- عرض المعادلة والمشتقة بصيغة LaTeX ---
st.subheader("📝 الدالة والمشتقة")
lc1, lc2 = st.columns(2)
lc1.latex(rf"f(x) = {sp.latex(f_expr)}")
if method != "Secant (القاطع)":
    lc2.latex(rf"f'(x) = {sp.latex(df_expr)}")

# --- ملخص النتيجة ---
st.subheader("🎯 النتيجة")
if result.converged:
    st.success(result.message)
else:
    st.warning(result.message)

m1, m2, m3 = st.columns(3)
m1.metric("الجذر النهائي", f"{result.root:.12f}")
m2.metric("f(root)", f"{safe_eval(f_num, result.root):.3e}")
m3.metric("عدد التكرارات", len(result.table))

# --- جدول التكرارات ---
st.subheader("📊 جدول التكرارات")
st.dataframe(
    result.table,
    use_container_width=True,
    hide_index=True,
    column_config={
        "i": st.column_config.NumberColumn("i", format="%d"),
        "x_i": st.column_config.NumberColumn("x_i", format="%.10f"),
        "f(x_i)": st.column_config.NumberColumn("f(x_i)", format="%.4e"),
        "f'(x_i) / الميل": st.column_config.NumberColumn("f'(x_i) / الميل", format="%.6f"),
        "x_{i+1}": st.column_config.NumberColumn("x_{i+1}", format="%.10f"),
        "|x_{i+1} - x_i|": st.column_config.NumberColumn("|x_{i+1} - x_i|", format="%.3e"),
    },
)
st.download_button(
    "⬇️ تحميل الجدول (CSV)",
    result.table.to_csv(index=False).encode("utf-8-sig"),
    file_name="iterations.csv",
    mime="text/csv",
)

# --- الرسم البياني ---
st.subheader("📈 الرسم البياني")
if np.isfinite(result.root):
    st.plotly_chart(build_plot(f_num, f_text, result, x0, show_path),
                    use_container_width=True)
else:
    st.error("لا يمكن رسم الدالة لأن الجذر غير معرّف.")
